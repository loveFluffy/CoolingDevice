This application will help you setup and control a LJTickDAC attached to
a U3, U6, or UE9. For most users running setup.exe will be sufficient but others
may need to get an update from Microsoft at:

x86 
http://www.microsoft.com/downloads/details.aspx?familyid=A5C84275-3B97-4AB7-A40D-3802B2AF5FC2&displaylang=en

x64 
http://www.microsoft.com/downloads/details.aspx?familyid=BA9257CA-337F-4B40-8C14-157CFDFFEE4E&displaylang=en

Regards,
Labjack Support